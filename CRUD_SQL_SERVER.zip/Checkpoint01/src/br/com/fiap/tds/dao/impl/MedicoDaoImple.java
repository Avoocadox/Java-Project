package br.com.fiap.tds.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.tds.dao.MedicoDao;
import br.com.fiap.tds.entity.Medico;

public class MedicoDaoImple extends GenericDaoImpl<Medico, Integer> implements MedicoDao{

	public MedicoDaoImple(EntityManager em) {
		super(em);
	}
}
