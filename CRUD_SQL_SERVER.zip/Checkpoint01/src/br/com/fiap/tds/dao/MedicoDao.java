package br.com.fiap.tds.dao;

import br.com.fiap.tds.entity.Medico;

public interface MedicoDao extends GenericDao<Medico, Integer>{

}
