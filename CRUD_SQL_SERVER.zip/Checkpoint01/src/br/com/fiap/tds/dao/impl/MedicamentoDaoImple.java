package br.com.fiap.tds.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.tds.dao.MedicamentoDao;
import br.com.fiap.tds.entity.Medicamento;

public class MedicamentoDaoImple extends GenericDaoImpl<Medicamento, Integer> implements MedicamentoDao{

	public MedicamentoDaoImple(EntityManager em) {
		super(em);
	}
}
