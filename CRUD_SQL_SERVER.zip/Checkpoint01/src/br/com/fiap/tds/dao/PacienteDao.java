package br.com.fiap.tds.dao;

import br.com.fiap.tds.entity.Paciente;

public interface PacienteDao extends GenericDao<Paciente, Integer>{

}
