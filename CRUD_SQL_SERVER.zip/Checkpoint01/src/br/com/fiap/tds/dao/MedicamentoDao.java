package br.com.fiap.tds.dao;

import br.com.fiap.tds.entity.Medicamento;

public interface MedicamentoDao extends GenericDao<Medicamento, Integer>{

}
