package br.com.fiap.tds.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TB_MEDICAMENTO")
@SequenceGenerator(name = "medicamento", sequenceName = "SQ_TB_MEDICAMENTO", allocationSize = 1)
public class Medicamento {
	
	@Id
	@Column(name = "nr_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "medicamento")
	private int idMedicamento;
	@Column(name = "ds_nome", nullable = false, length = 80)
	private String nome;
	@Column(name = "ds_descricao", nullable = false, length = 80)
	private String descricao;
	@Column(name = "nr_qtdMedicamento", nullable = false, length = 20)
	private int qtdMedicamento;
	@Enumerated(EnumType.STRING)
	@Column(name = "TipoMedicamento", length = 50)
	private TipoMedicamento tipoMedicamento;


	
	public Medicamento() {
	}
	
	public Medicamento(int idMedicamento, String nome, String descricao, int qtdMedicamento, TipoMedicamento tipoMedicamento) {
		this.idMedicamento = idMedicamento;
		this.nome = nome;
		this.descricao = descricao;
		this.qtdMedicamento = qtdMedicamento;
		this.tipoMedicamento = tipoMedicamento;

	}
	
	public Medicamento(String nome, String descricao, int qtdMedicamento, TipoMedicamento tipoMedicamento) {
		this.nome = nome;
		this.descricao = descricao;
		this.qtdMedicamento = qtdMedicamento;
		this.tipoMedicamento = tipoMedicamento;

	}
	




	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getDescricao() {
		return descricao;
	}



	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}



	public int getQtdMedicamento() {
		return qtdMedicamento;
	}



	public void setQtdMedicamento(int qtdMedicamento) {
		this.qtdMedicamento = qtdMedicamento;
	}



	public TipoMedicamento getTipoMedicamento() {
		return tipoMedicamento;
	}



	public void setTipoMedicamento(TipoMedicamento tipoMedicamento) {
		this.tipoMedicamento = tipoMedicamento;
	}



	public int getIdMedicamento() {
		return idMedicamento;
	}



	public void setIdMedicamento(int idMedicamento) {
		this.idMedicamento = idMedicamento;
	}



}
