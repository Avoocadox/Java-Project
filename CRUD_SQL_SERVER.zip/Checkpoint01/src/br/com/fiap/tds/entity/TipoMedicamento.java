package br.com.fiap.tds.entity;

public enum TipoMedicamento {
	SemTarja, TarjaAmarela, TarjaVermelhaSemReceita, TarjaVermelhaComReceita, TarjaPreta 
}
