package br.com.fiap.tds.entity;

public enum Especialidade {
	Ginecologista, Dermatologista, Neurologista, Oftamologista, Otorrinolaringologista, ClinicoGeral
}
