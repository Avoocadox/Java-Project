package br.com.fiap.tds.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "TB_PACIENTE")
public class Paciente {
	
	@Column(name = "ds_nome", nullable = false, length = 100)
	private String nome;
	
	@Column(name = "ds_sobrenome", nullable = false, length = 100)
	private String sobrenome;
	@Id
	@Column(name = "nr_cpf", nullable = false, length = 11)
	private int cpf;
	
	@Column(name = "nr_telefone", nullable = false, length = 11)
	private String telefone;
	
	@Column(name = "ds_doenca", length = 100)
	private String doenca;
	
	@Column(name = "ds_email", length = 100)
	private String email;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar consulta;
	
	
	
	
	public Paciente() {
		
	}
	
	public Paciente(String nome, String sobrenome, int cpf, String telefone, String doenca, String email, Calendar consulta) {
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
		this.telefone = telefone;
		this.doenca = doenca;
		this.email = email;
		this.consulta = consulta;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getDoenca() {
		return doenca;
	}
	public void setDoenca(String doenca) {
		this.doenca = doenca;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
