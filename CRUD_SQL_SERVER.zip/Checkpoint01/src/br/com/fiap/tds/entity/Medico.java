package br.com.fiap.tds.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_MEDICO")
public class Medico {
	
	@Column(name = "ds_nome", nullable = false, length = 100)
	private String nome;
	
	@Column(name = "ds_sobrenome", nullable = false, length = 100)
	private String sobrenome;
	
	@Id
	@Column(name = "nr_crm", nullable = false, length = 10)
	private int crm;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "ds_especialidade", length = 50)
	private Especialidade especialidade;
	
	public Medico(){
		
	}
	
	
	public Medico(String nome, String sobrenome, int crm, Especialidade especialidade) {
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.crm = crm;
		this.especialidade = especialidade;
	}

	
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public int getCrm() {
		return crm;
	}
	public void setCrm(int crm) {
		this.crm = crm;
	}
	public Especialidade getEspecialidade() {
		return especialidade;
	}
	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}

	
}
