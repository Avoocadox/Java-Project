package br.com.fiap.tds.exceptions;

@SuppressWarnings("serial")
public class CommitException extends Exception {
	
	
	public CommitException() {
		
	}
	public CommitException(String msg) {
		super(msg);
	}
}
