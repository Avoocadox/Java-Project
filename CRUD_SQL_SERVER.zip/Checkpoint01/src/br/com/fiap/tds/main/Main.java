package br.com.fiap.tds.main;

import java.util.Calendar;

import javax.persistence.EntityManager;

import br.com.fiap.tds.FactorySingleton.EntityManagerFactorySingleton;
import br.com.fiap.tds.dao.GenericDao;
import br.com.fiap.tds.dao.impl.GenericDaoImpl;
import br.com.fiap.tds.entity.Especialidade;
import br.com.fiap.tds.entity.Medicamento;
import br.com.fiap.tds.entity.Medico;
import br.com.fiap.tds.entity.Paciente;
import br.com.fiap.tds.entity.TipoMedicamento;
import br.com.fiap.tds.exceptions.CommitException;

public class Main {
	public static void main(String[] args) {
	
	EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
	
	GenericDao<Medico, Integer> daoMedico = new GenericDaoImpl<Medico, Integer>(em) {};
	Medico medico = new Medico("Fillipi","Silva",36965,Especialidade.Neurologista);
	
	
	GenericDao<Paciente, Integer> daoPaciente = new GenericDaoImpl<Paciente, Integer>(em) {};
	Paciente paciente = new Paciente("Roberto","Costa",45210486,"1155630235","Insonia","roberto@costa.com",Calendar.getInstance());
	
	
	GenericDao<Medicamento, Integer> daoMedicamento = new GenericDaoImpl<Medicamento, Integer>(em) {};
	Medicamento medicamento = new Medicamento("Nortriptilina","Son�fero",1,TipoMedicamento.TarjaPreta);
	try {
		daoMedico.create(medico);
		daoMedico.commit();
		System.out.println("M�dico Cadastrado!");
		daoPaciente.create(paciente);
		daoPaciente.commit();
		System.out.println("Paciente Cadastrado!");
		daoMedicamento.create(medicamento);
		daoMedicamento.commit();
		System.out.println("Medicamento Cadastrado");

	} catch (CommitException e) {
		System.out.println(e.getMessage());
		
	}
	
	em.close();
	EntityManagerFactorySingleton.getInstance().close();
	}
}
